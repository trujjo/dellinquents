document.addEventListener('DOMContentLoaded', () => {
    console.log("Welcome to Dell Med Underground!");
});